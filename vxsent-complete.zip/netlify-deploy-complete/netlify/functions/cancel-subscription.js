// netlify/functions/cancel-subscription.js
// Cancels Solo subscription at period end.

import { getStripe, getSupabase, ok, err, cors, verifySession } from '../../src/lib/index.js';

export const handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return cors();
  if (event.httpMethod !== 'POST') return err('Method not allowed', 405);

  const user = await verifySession(event);
  if (!user) return err('Authentication required', 401);

  try {
    const stripe = getStripe();
    const supabase = getSupabase();

    // Find active subscription
    const { data: sub } = await supabase
      .from('subscriptions')
      .select('stripe_subscription_id')
      .eq('user_id', user.id)
      .eq('status', 'active')
      .single();

    if (!sub) return err('No active subscription found', 404);

    // Cancel at period end (not immediately)
    await stripe.subscriptions.update(sub.stripe_subscription_id, {
      cancel_at_period_end: true
    });

    return ok({
      message: 'Subscription will cancel at the end of the current period.',
      cancelAtPeriodEnd: true
    });

  } catch (error) {
    console.error('cancel-subscription error:', error);
    return err('Failed to cancel subscription', 500);
  }
};
