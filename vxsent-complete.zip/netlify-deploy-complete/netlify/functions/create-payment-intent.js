// netlify/functions/create-payment-intent.js
// Now collects recipient email for RAC chain.
// recipientEmail is optional — works without it (backward compatible).

import { getStripe, getSupabase, generateProofId, ok, err, cors } from '../../src/lib/index.js';

export const handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return cors();
  if (event.httpMethod !== 'POST') return err('Method not allowed', 405);

  let body;
  try { body = JSON.parse(event.body); }
  catch { return err('Invalid request body'); }

  const {
    fileHash, fileName, fileSize, timestamp,
    email,            // sender email
    recipientEmail,   // NEW: client email for RAC chain
    projectName       // NEW: project name for RAC scope
  } = body;

  if (!fileHash || fileHash.length !== 64) return err('Invalid file hash');
  if (!fileName) return err('File name required');
  if (!fileSize) return err('File size required');
  if (!timestamp) return err('Timestamp required');
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return err('Invalid sender email');
  if (recipientEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(recipientEmail)) return err('Invalid recipient email');

  try {
    const stripe = getStripe();
    const proofId = generateProofId();

    const paymentIntent = await stripe.paymentIntents.create({
      amount: 99,
      currency: 'usd',
      automatic_payment_methods: { enabled: true },
      metadata: {
        proof_id: proofId,
        file_hash: fileHash,
        file_name: fileName.substring(0, 100),
        file_size: fileSize,
        timestamp,
        user_email: email || '',
        recipient_email: recipientEmail || '',   // RAC: authorized recipient
        project_name: (projectName || '').substring(0, 100), // RAC: project scope
        product: 'day_pass'
      },
      description: `SENT. delivery proof — ${fileName}`,
      receipt_email: email || undefined,
      statement_descriptor: 'SENT PROOF'
    });

    const supabase = getSupabase();
    await supabase.from('proofs').insert({
      id: proofId,
      file_name: fileName,
      file_size: fileSize,
      file_hash: fileHash,
      sealed_at: timestamp,
      stripe_payment_id: paymentIntent.id,
      user_email: email || null,
      // RAC fields stored on the proof record
      recipient_email: recipientEmail || null,
      project_name: projectName || null,
      is_valid: false
    });

    await supabase.from('payments').insert({
      stripe_payment_id: paymentIntent.id,
      user_email: email || null,
      amount: 99,
      currency: 'usd',
      payment_type: 'day_pass',
      status: 'pending',
      proof_id: proofId
    });

    return ok({
      clientSecret: paymentIntent.client_secret,
      proofId,
      publishableKey: process.env.STRIPE_PUBLISHABLE_KEY
    });

  } catch (error) {
    console.error('create-payment-intent error:', error);
    return err('Payment initialization failed. Please try again.', 500);
  }
};
