// netlify/functions/auth-session.js
// Returns current authenticated user data.
// Called by dashboard and other protected pages on load.

import { ok, err, cors, verifySession } from '../../src/lib/index.js';

export const handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return cors();
  if (event.httpMethod !== 'GET') return err('Method not allowed', 405);

  const user = await verifySession(event);

  if (!user) {
    return err('Not authenticated', 401);
  }

  return ok({
    id: user.id,
    email: user.email,
    plan: user.plan,
    planExpiresAt: user.plan_expires_at,
    createdAt: user.created_at
  });
};
