// netlify/functions/confirm-receipt.js
// Level 3: Recipient actively confirms they received the delivery.
// Called when recipient clicks "Confirm Receipt" on the verify page.
// This is the strongest possible proof — the client themselves confirmed.

import { getSupabase, ok, err, cors } from '../../src/lib/index.js';

export const handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return cors();
  if (event.httpMethod !== 'POST') return err('Method not allowed', 405);

  let body;
  try { body = JSON.parse(event.body); }
  catch { return err('Invalid request body'); }

  const { proofId } = body;
  if (!proofId || !proofId.startsWith('SENT-')) return err('Valid proof ID required');

  const ip = event.headers['x-forwarded-for']?.split(',')[0]?.trim()
    || event.headers['x-real-ip'] || 'unknown';

  try {
    const supabase = getSupabase();

    // Verify proof exists and is valid
    const { data: proof } = await supabase
      .from('proofs').select('id, is_valid, user_email, file_name, recipient_email')
      .eq('id', proofId).single();

    if (!proof || !proof.is_valid) return err('Proof not found', 404);

    // Log confirmation event
    await supabase.from('proof_access_events').insert({
      proof_id: proofId,
      ip_address: ip,
      user_agent: event.headers['user-agent'] || null,
      confirmed: true,
      confirmed_at: new Date().toISOString()
    });

    // Notify the proof owner (sender) by email
    const resendKey = process.env.RESEND_API_KEY;
    if (resendKey && proof.user_email) {
      const baseUrl = process.env.URL || 'https://vxsent.com';
      await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${resendKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          from: 'SENT. <receipts@vxsent.com>',
          to: proof.user_email,
          subject: `Delivery confirmed — ${proof.file_name}`,
          html: `
            <div style="font-family:'DM Sans',sans-serif;max-width:480px;margin:0 auto;padding:40px 20px;background:#f5f6f8">
              <div style="background:#fff;border:1px solid #e1e4e8;border-radius:8px;padding:32px;border-top:3px solid #00b356">
                <div style="font-family:'Bebas Neue',sans-serif;font-size:20px;color:#00b356;margin-bottom:16px">✓ DELIVERY CONFIRMED BY RECIPIENT</div>
                <p style="font-size:14px;color:#374151;line-height:1.65;margin-bottom:16px">
                  Your delivery of <strong>${proof.file_name}</strong> has been confirmed by the recipient.
                </p>
                <div style="background:#f0f2f5;border-radius:4px;padding:12px 16px;font-family:'JetBrains Mono',monospace;font-size:10px;color:#374151;margin-bottom:16px">
                  <div>Proof ID: ${proofId}</div>
                  <div>Confirmed at: ${new Date().toUTCString()}</div>
                  <div>IP: ${ip}</div>
                </div>
                <a href="${baseUrl}/receipt?id=${proofId}" style="display:inline-block;padding:12px 22px;background:#00b356;color:#fff;text-decoration:none;font-family:'Bebas Neue',sans-serif;font-size:16px;letter-spacing:0.1em;border-radius:4px">VIEW RECEIPT →</a>
              </div>
            </div>
          `
        })
      });
    }

    return ok({
      confirmed: true,
      proofId,
      confirmedAt: new Date().toISOString(),
      message: 'Receipt confirmed. The sender has been notified.'
    });

  } catch (error) {
    console.error('confirm-receipt error:', error);
    return err('Failed to confirm receipt', 500);
  }
};
