// netlify/functions/auth-logout.js
// Clears session cookie and invalidates token.

import { getSupabase, cors, getSessionFromCookie } from '../../src/lib/index.js';

export const handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return cors();

  const sessionToken = getSessionFromCookie(event);

  if (sessionToken) {
    try {
      const supabase = getSupabase();
      // Invalidate the session token
      await supabase.from('users').update({
        magic_token: null,
        magic_token_expires: null
      }).eq('magic_token', sessionToken);
    } catch (e) {
      console.error('Logout DB error:', e);
    }
  }

  // Clear cookie and redirect
  return {
    statusCode: 302,
    headers: {
      'Location': '/',
      'Set-Cookie': [
        'vxsent_session=; HttpOnly; Secure; SameSite=Strict; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT',
        'vxsent_email=; Secure; SameSite=Strict; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT'
      ].join(', ')
    },
    body: ''
  };
};
