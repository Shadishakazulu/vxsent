// netlify/functions/get-proofs.js
// Returns paginated list of proofs for authenticated user.
// Called by dashboard.html to populate the proof list.

import { getSupabase, ok, err, cors, verifySession } from '../../src/lib/index.js';

export const handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return cors();
  if (event.httpMethod !== 'GET') return err('Method not allowed', 405);

  // Verify user session
  const user = await verifySession(event);
  if (!user) return err('Authentication required', 401);

  // Pagination params
  const page = parseInt(event.queryStringParameters?.page) || 1;
  const limit = Math.min(parseInt(event.queryStringParameters?.limit) || 20, 50);
  const offset = (page - 1) * limit;
  const filter = event.queryStringParameters?.filter || 'all';

  try {
    const supabase = getSupabase();

    let query = supabase
      .from('proofs')
      .select('id, file_name, file_size, file_hash, sealed_at, is_valid', { count: 'exact' })
      .eq('user_id', user.id)
      .eq('is_valid', true)
      .order('sealed_at', { ascending: false })
      .range(offset, offset + limit - 1);

    // Apply filter
    if (filter === 'month') {
      const monthAgo = new Date();
      monthAgo.setMonth(monthAgo.getMonth() - 1);
      query = query.gte('sealed_at', monthAgo.toISOString());
    }

    const { data: proofs, count, error } = await query;

    if (error) throw error;

    // Get stats
    const { count: totalCount } = await supabase
      .from('proofs')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', user.id)
      .eq('is_valid', true);

    // Get total value (count of proofs as proxy — no financial data stored per proof)
    const { count: monthCount } = await supabase
      .from('proofs')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', user.id)
      .eq('is_valid', true)
      .gte('sealed_at', new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString());

    return ok({
      proofs: proofs.map(p => ({
        id: p.id,
        fileName: p.file_name,
        fileSize: p.file_size,
        fileHash: p.file_hash.substring(0, 8) + '...' + p.file_hash.substring(56),
        sealedAt: p.sealed_at,
        isValid: p.is_valid,
        receiptUrl: `https://vxsent.com/receipt?id=${p.id}`,
        verifyUrl: `https://vxsent.com/verify/${p.id}`
      })),
      pagination: {
        total: count,
        page,
        limit,
        pages: Math.ceil(count / limit)
      },
      stats: {
        totalProofs: totalCount || 0,
        monthProofs: monthCount || 0,
        plan: user.plan,
        planExpiresAt: user.plan_expires_at
      }
    });

  } catch (error) {
    console.error('get-proofs error:', error);
    return err('Failed to retrieve proofs', 500);
  }
};
