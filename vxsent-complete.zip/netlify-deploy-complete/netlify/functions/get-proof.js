// netlify/functions/get-proof.js
// Now returns RAC chain data + access logging (Level 2 proof).

import { getSupabase, ok, err, cors } from '../../src/lib/index.js';

export const handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return cors();
  if (event.httpMethod !== 'GET') return err('Method not allowed', 405);

  const proofId = event.queryStringParameters?.id || event.path.split('/').pop();
  if (!proofId || !proofId.startsWith('SENT-')) return err('Valid proof ID required', 400);

  try {
    const supabase = getSupabase();

    const { data: proof, error } = await supabase
      .from('proofs')
      .select(`
        id, file_name, file_size, file_hash,
        veridex_proof_id, veridex_signature,
        sealed_at, is_valid,
        recipient_email, project_name,
        rac_chain_hash, rac_enabled
      `)
      .eq('id', proofId)
      .single();

    if (error || !proof) return err('Proof not found', 404);
    if (!proof.is_valid) return err('Proof pending — payment processing', 402);

    // ── LEVEL 2: Log access event ──
    // Every time someone opens the verify URL, we record it.
    // This is what proves the client accessed the proof.
    const ip = event.headers['x-forwarded-for']?.split(',')[0]?.trim()
      || event.headers['x-real-ip']
      || 'unknown';

    await supabase.from('proof_access_events').insert({
      proof_id: proofId,
      ip_address: ip,
      user_agent: event.headers['user-agent'] || null,
      referrer: event.headers['referer'] || null,
      confirmed: false
    });

    // Get access count for display
    const { count: accessCount } = await supabase
      .from('proof_access_events')
      .select('*', { count: 'exact', head: true })
      .eq('proof_id', proofId);

    // Check if recipient confirmed
    const { data: confirmation } = await supabase
      .from('proof_access_events')
      .select('confirmed_at')
      .eq('proof_id', proofId)
      .eq('confirmed', true)
      .single();

    return ok({
      id: proof.id,
      fileName: proof.file_name,
      fileSize: proof.file_size,
      fileHash: proof.file_hash,
      veridexProofId: proof.veridex_proof_id,
      veridexSignature: proof.veridex_signature,
      sealedAt: proof.sealed_at,
      isValid: proof.is_valid,
      verifyUrl: `https://vxsent.com/verify/${proof.id}`,
      // RAC chain data
      rac: {
        enabled: proof.rac_enabled || false,
        chainHash: proof.rac_chain_hash || null,
        authorizedRecipient: proof.recipient_email || null,
        project: proof.project_name || null
      },
      // Level 2: access tracking
      accessCount: accessCount || 0,
      recipientConfirmed: !!confirmation,
      recipientConfirmedAt: confirmation?.confirmed_at || null
    });

  } catch (error) {
    console.error('get-proof error:', error);
    return err('Failed to retrieve proof', 500);
  }
};
