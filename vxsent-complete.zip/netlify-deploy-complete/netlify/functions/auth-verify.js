// netlify/functions/auth-verify.js
// Verifies the magic link token from email.
// Creates a session cookie and redirects to dashboard.

import { randomBytes } from 'crypto';
import { getSupabase } from '../../src/lib/index.js';

export const handler = async (event) => {
  const { token, email } = event.queryStringParameters || {};

  if (!token || !email) {
    return redirect('/login?error=invalid_link');
  }

  try {
    const supabase = getSupabase();

    // Find user with valid token
    const { data: user, error } = await supabase
      .from('users')
      .select('id, email, plan, magic_token, magic_token_expires')
      .eq('email', decodeURIComponent(email))
      .eq('magic_token', token)
      .single();

    if (error || !user) {
      return redirect('/login?error=invalid_token');
    }

    // Check token hasn't expired
    if (new Date(user.magic_token_expires) < new Date()) {
      return redirect('/login?error=expired_token');
    }

    // Generate session token (different from magic token)
    const sessionToken = randomBytes(48).toString('hex');
    const sessionExpires = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // 30 days

    // Store session token (reuse magic_token field with long expiry)
    await supabase.from('users').update({
      magic_token: sessionToken,
      magic_token_expires: sessionExpires.toISOString()
    }).eq('id', user.id);

    // Set secure session cookie and redirect to dashboard
    return {
      statusCode: 302,
      headers: {
        'Location': '/dashboard',
        'Set-Cookie': [
          `vxsent_session=${sessionToken}; HttpOnly; Secure; SameSite=Strict; Path=/; Expires=${sessionExpires.toUTCString()}`,
          `vxsent_email=${encodeURIComponent(user.email)}; Secure; SameSite=Strict; Path=/; Expires=${sessionExpires.toUTCString()}`
        ].join(', ')
      },
      body: ''
    };

  } catch (error) {
    console.error('auth-verify error:', error);
    return redirect('/login?error=server_error');
  }
};

function redirect(url) {
  return {
    statusCode: 302,
    headers: { 'Location': url },
    body: ''
  };
}
