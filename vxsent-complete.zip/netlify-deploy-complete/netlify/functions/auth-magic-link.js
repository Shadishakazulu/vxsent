// netlify/functions/auth-magic-link.js
// Sends a magic link email for passwordless login.
// Creates user if they don't exist.

import { randomBytes } from 'crypto';
import { getSupabase, sendMagicLinkEmail, ok, err, cors } from '../../src/lib/index.js';

export const handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return cors();
  if (event.httpMethod !== 'POST') return err('Method not allowed', 405);

  let body;
  try {
    body = JSON.parse(event.body);
  } catch {
    return err('Invalid request body');
  }

  const { email } = body;

  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return err('Valid email required');
  }

  // Rate limiting — max 3 magic links per email per hour
  // In production add Redis or Upstash for rate limiting
  // For now use DB-based check
  try {
    const supabase = getSupabase();

    // Find or create user
    let { data: user } = await supabase
      .from('users')
      .select('id, email, plan')
      .eq('email', email)
      .single();

    if (!user) {
      const { data: newUser, error } = await supabase
        .from('users')
        .insert({ email, plan: 'none' })
        .select()
        .single();

      if (error) throw error;
      user = newUser;
    }

    // Generate secure magic token (16 bytes = 32 hex chars)
    const token = randomBytes(32).toString('hex');
    const expires = new Date(Date.now() + 15 * 60 * 1000); // 15 minutes

    // Store token
    await supabase.from('users').update({
      magic_token: token,
      magic_token_expires: expires.toISOString()
    }).eq('id', user.id);

    // Send magic link email
    await sendMagicLinkEmail({
      email,
      token,
      plan: user.plan
    });

    return ok({
      message: 'Magic link sent. Check your email.',
      // In development, return the token for testing
      ...(process.env.NODE_ENV !== 'production' && { _dev_token: token })
    });

  } catch (error) {
    console.error('auth-magic-link error:', error);
    return err('Failed to send magic link. Please try again.', 500);
  }
};
