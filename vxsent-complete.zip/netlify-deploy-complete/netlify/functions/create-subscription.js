// netlify/functions/create-subscription.js
// Creates a Stripe subscription for $12.99/month Solo plan
// Called from pricing page when user clicks "START SOLO"

import { getStripe, getSupabase, ok, err, cors, verifySession } from '../../src/lib/index.js';

export const handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return cors();
  if (event.httpMethod !== 'POST') return err('Method not allowed', 405);

  let body;
  try {
    body = JSON.parse(event.body);
  } catch {
    return err('Invalid request body');
  }

  const { email, paymentMethodId } = body;

  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return err('Valid email required');
  }

  try {
    const stripe = getStripe();
    const supabase = getSupabase();

    // Find or create user
    let { data: user } = await supabase
      .from('users')
      .select('*')
      .eq('email', email)
      .single();

    let stripeCustomerId = user?.stripe_customer_id;

    // Create Stripe customer if needed
    if (!stripeCustomerId) {
      const customer = await stripe.customers.create({
        email,
        metadata: { source: 'vxsent_solo' }
      });
      stripeCustomerId = customer.id;

      if (user) {
        await supabase.from('users')
          .update({ stripe_customer_id: stripeCustomerId })
          .eq('email', email);
      } else {
        // Create new user
        const { data: newUser } = await supabase.from('users').insert({
          email,
          stripe_customer_id: stripeCustomerId,
          plan: 'none'
        }).select().single();
        user = newUser;
      }
    }

    // Attach payment method to customer if provided
    if (paymentMethodId) {
      await stripe.paymentMethods.attach(paymentMethodId, {
        customer: stripeCustomerId
      });
      await stripe.customers.update(stripeCustomerId, {
        invoice_settings: { default_payment_method: paymentMethodId }
      });
    }

    // Create subscription
    // STRIPE_SOLO_PRICE_ID must be set in Netlify env vars
    // Create this price in Stripe Dashboard: $12.99/month recurring
    const subscription = await stripe.subscriptions.create({
      customer: stripeCustomerId,
      items: [{ price: process.env.STRIPE_SOLO_PRICE_ID }],
      payment_behavior: 'default_incomplete',
      payment_settings: { save_default_payment_method: 'on_subscription' },
      expand: ['latest_invoice.payment_intent'],
      metadata: {
        user_email: email,
        plan: 'solo'
      }
    });

    const clientSecret = subscription.latest_invoice?.payment_intent?.client_secret;

    return ok({
      subscriptionId: subscription.id,
      clientSecret,
      publishableKey: process.env.STRIPE_PUBLISHABLE_KEY,
      status: subscription.status
    });

  } catch (error) {
    console.error('create-subscription error:', error);
    return err('Subscription creation failed. Please try again.', 500);
  }
};
